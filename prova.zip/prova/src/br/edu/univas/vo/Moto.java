package br.edu.univas.vo;

public class Moto extends Veiculo{

}
