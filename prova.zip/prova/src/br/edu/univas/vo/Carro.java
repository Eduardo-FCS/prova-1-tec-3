package br.edu.univas.vo;

public class Carro extends Veiculo {
	
	

}
