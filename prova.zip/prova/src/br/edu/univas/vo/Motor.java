package br.edu.univas.vo;

public class Motor {
	
	private double torque;
	private int potencia;
	
	
	public double getTorque() {
		return torque;
	}
	public void setTorque(double torque) {
		this.torque = torque;
	}
	public int getPotencia() {
		return potencia;
	}
	public void setPotencia(int potencia) {
		this.potencia = potencia;
	}
	
	

}
