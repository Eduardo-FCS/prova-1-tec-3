package br.edu.univas.main;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import br.edu.univas.vo.Carro;
import br.edu.univas.vo.Competidor;
import br.edu.univas.vo.Moto;

public class StartApp {

	private static ArrayList<Competidor> competidores = new ArrayList<>();

	private static Scanner leitor = new Scanner(System.in);

	public static void main(String[] args) {

	        for (int i = 0; i < 5; i++) {
	        	
	        	System.out.println("==================================" + "\n" + "RACE GAME" + "\n");
	            System.out.println("Competidor " + (i + 1));
	            Competidor competidor = new Competidor();
	            System.out.println("Digite abaixo o apelido que deseja utilizar:");
	            competidor.setApelido(leitor.nextLine());

	            System.out.println("Selecione a modalidade abaixo:" + "\n" + "1) Carro;" + "\n" + "2) Moto;");
	            int number = leitor.nextInt();
	            leitor.nextLine();

	            if (number == 1) {
	                Carro carro = new Carro();
	                competidor.setVeiculo(carro);
	                competidores.add(competidor);

	            }

	            else if (number == 2) {
	                Moto moto = new Moto();
	                competidor.setVeiculo(moto);
	                competidores.add(competidor);

	            }

	        }

	        for (int i = 0; i < 10; i++) {

	            Random comp1 = new Random();
	            int aceleracao1 = comp1.nextInt((20 - 5) + 1) + 5;
	            competidores.get(0).getVeiculo().acelerar(aceleracao1);

	            Random comp2 = new Random();
	            int aceleracao2 = comp2.nextInt((20 - 5) + 1) + 5;
	            competidores.get(1).getVeiculo().acelerar(aceleracao2);

	            Random comp3 = new Random();
	            int aceleracao3 = comp3.nextInt((20 - 5) + 1) + 5;
	            competidores.get(2).getVeiculo().acelerar(aceleracao3);

	            Random comp4 = new Random();
	            int aceleracao4 = comp4.nextInt((20 - 5) + 1) + 5;
	            competidores.get(3).getVeiculo().acelerar(aceleracao4);

	            Random comp5 = new Random();
	            int aceleracao5 = comp5.nextInt((20 - 5) + 1) + 5;
	            competidores.get(4).getVeiculo().acelerar(aceleracao5);
	        }
	        
	}
}
